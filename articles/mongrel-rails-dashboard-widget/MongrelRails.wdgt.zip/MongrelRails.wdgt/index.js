if (window.widget){
    widget.onshow = onshow;
    widget.onhide = onhide;
}


function firstLoad(){
    // This automagically fills in the version number for you if there's a div
    // with an id="version". See version() in prefs.js.
    if(null != document.getElementById("version")){
      document.getElementById("version").innerText = "v"+version();
    }

    new AppleGlassButton(document.getElementById("restartButton"), "Restart", restartMongrel);
    new AppleGlassButton(document.getElementById("startButton"), "Start", startMongrel);
    new AppleGlassButton(document.getElementById("stopButton"), "Stop", stopMongrel);

    // Apple Glass Button usage:
    // AppleGlassButton(HostElement, "Caption", actionWhenClicked);
    new AppleGlassButton(document.getElementById("doneButton"), "Save", doFlipToFront);

    // AppleInfoButton usage:
    // AppleInfoButton(HostElement, HoverTriggerElement, foreColor, backColor, actionWhenClicked);
    new AppleInfoButton(document.getElementById("eyeButton"), document.getElementById("front"), "black", "black", doFlipToBack);

    if(window.widget) {
      var mongrel_cluster_dir = widget.preferenceForKey("mongrel_cluster_dir");

    if (mongrel_cluster_dir && mongrel_cluster_dir.length > 0) {                                                                                       // they are restored.
      setMongrelClusterDir(mongrel_cluster_dir);
      setSelectYmlOptions();
    }else {
      setOutput("Please configure your mongrel cluster directory first by clicking on the (i) button.");
    }
  }
}


function onhide(){
    //Kill all processing here.
}


function onshow(){
    //Start processing again.
    setOutput('');
}

function restartMongrel() { mongrelControl('restart'); }
function startMongrel() { mongrelControl('start'); }
function stopMongrel() { mongrelControl('stop'); }

function mongrelControl(action) {
  select_yml = document.getElementById('select_yml');
  yml = select_yml.options[select_yml.selectedIndex].value;

  switch(action) {
    case 'restart':
      nice_action = "Restarting";
      break;
    case 'start':
      nice_action = "Starting";
      break;
    case 'stop':
      nice_action = "Stopping";
      break;
    default:
      nice_action = action;
      break;
  }

  if ( yml.length > 0 ) { // not 'All Mongrels'
    setOutput(nice_action + " " + yml + "...");
    sys = widget.system("/bin/sh -l -c 'mongrel_rails cluster::" + action + " -C " + getMongrelClusterDir() + "/" + yml + ".yml'", null);
  }else {
    select_yml = document.getElementById('select_yml');
    output = nice_action + ' ';
    for( i = 1; i <= select_yml.options.length; i++ ) {
      yml = select_yml.options[i].value;
      sys = widget.system("/bin/sh -l -c 'mongrel_rails cluster::" + action + " -C " + getMongrelClusterDir() + "/" + yml + ".yml'", null);
      output += yml + '... ';
      setOutput(output);
    }
  }
}

function getMongrelClusterDir() {
  return document.getElementById("mongrel_cluster_dir").value;
}

function setMongrelClusterDir(str) {
  document.getElementById("mongrel_cluster_dir").value = str;
}

function setOutput(str) {
  document.getElementById('output').innerHTML = str;
}

function setSelectYmlOptions() {
  select_yml = document.getElementById('select_yml');
  select_yml.options.length = 0;
  select_yml.options[0] = new Option('All Mongrels', '');
  sys = widget.system("cd " + getMongrelClusterDir() + "&& ls *.yml | sed 's/.yml//'", null);
  ymls = sys.outputString.split("\n");
  for ( i = 0; i < ymls.length; i++ ) {
    if ( ymls[i].length > 0 ) {
      select_yml.options[i + 1] = new Option(ymls[i], ymls[i]);
    }
  }
}

/// These flip the widget from front to back, and from back to front,
/// respectively.
function doFlipToBack(){
    var front = document.getElementById("front");
    var back = document.getElementById("back");
	
    if(window.widget){
      widget.prepareForTransition("ToBack");
    }

    front.style.display="none";
    back.style.display="block";

    if(window.widget){
      setTimeout("widget.performTransition();", 0);
    }
}


function doFlipToFront(){
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if(window.widget){
      dir = getMongrelClusterDir();
      if ( dir.length > 0 ) {
        widget.setPreferenceForKey(dir, "mongrel_cluster_dir");
        setSelectYmlOptions();
        setOutput('');
      }
      widget.prepareForTransition("ToFront");
    }

    back.style.display="none";
    front.style.display="block";
	
    if(window.widget){
      setTimeout("widget.performTransition();", 0);
    }
}

function version(){
    var xmlReq = new XMLHttpRequest(); 
    xmlReq.open("GET", "Info.plist", false); 
    xmlReq.send(null); 
    
    var xml = xmlReq.responseXML; 
    var keys = xml.getElementsByTagName("key");
    var ver = "0.0";

    for(i=0; i<keys.length; i++){
      if("CFBundleVersion" == keys[i].firstChild.data){
          ver = keys[i].nextSibling.nextSibling.firstChild.data;
          break;
      }
    }

    return ver; 
}
